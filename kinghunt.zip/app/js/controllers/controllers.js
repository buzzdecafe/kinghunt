'use strict';

/* Controllers */

angular.module('kinghunt.controllers', []);
