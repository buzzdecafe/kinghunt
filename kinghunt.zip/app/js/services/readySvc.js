angular.module('kinghunt.services').
    factory('readySvc', ['$window', '$q', 'defaultBook', 'defaultSolved', function($window, $q, defaultBook, defaultSolved) {


    }]);